##Script for Periodization 
#Author: Stefania Degaetano-Ortlieb 
#Date: 2018
#Note: based on Rscript of Peter Fankhauser on comparing corpora
#If used please cite 
#Degaetano-Ortlieb, S. and Teich, E. (2018). Using relative entropy for detection and analysis of periods of diachronic linguistic change. In Proceedings of the 2nd Joint SIGHUM Workshop on Computational Linguistics for Cultural Heritage, Social Sciences, Humanities and Literature at COLING2018. Santa Fe, NM, USA. ACL.
###### Fankhauser et al. 2014, Exploring and Visualizing Variation in Language Resources when publishing smth based on this script
###### to compute distance measures and perform t-test on pairs of corpora represented
###### as (smoothed) unigram language models



#Prepare classes for KLD calculation
#Stefania Degaetano-Ortlieb 30.01.2018
#adapted 08.05.2018, Stefania Degaetano-Ortlieb

#Set working directory
setwd("C:\\Users\\Stefania\\Documents\\Stefania\\Dokumente\\Uni\\Konferenzen\\Coling2018\\released_script")

#Read in file 
#Input format: Tab or semicolon delimited matrix with features as columns and text-ids as rows
d4kld <- read.table(choose.files(), sep = ";", header = T)
#d4kld <- read.table(choose.files(), sep = "\t", header = T)


#Define parameters for periodization
gap <- 5 #gap for sliding window
span <- 20  #period range of comparison
firstp <- 1720 #starting year
range <- 1849 - firstp #range of period to be analyzed
period <- range/gap  #period to be analyzed

#Loop over the period to be analyzed
 for(i in 1:period){
   
   cs <- firstp #gap start year
   ce <- firstp +gap-1 #gap end year 
   pres <- cs-1 - span #pre-period start
   pree <- pres +span  #pre-period end
   poste <- ce+1+span  #post-period start
   posts <- poste-span #post-period end
   p <- paste("p",firstp, sep = "") #name for column

   d4kld[[p]][d4kld$year>=pres & d4kld$year<=pree]<- "pre"   #insert column and define pre period
   d4kld[[p]][d4kld$year>=cs & d4kld$year<=ce]<- "gap"       #define gap
   d4kld[[p]][d4kld$year>=posts & d4kld$year<=poste]<- "post" #define post period
   
   firstp <- firstp +gap #slide over the time line based on gap
   
 }

#Output file for KLD calculation
write.table(d4kld, "C:\\Users\\Stefania\\Documents\\Stefania\\Dokumente\\Uni\\Konferenzen\\Coling2018\\released_script\\data_periodization.csv", sep=";", row.names = F, quote = F)

# ESU 2015, Leipzig
# Workshop: Comparing Corpora
# Peter Fankhauser
# compute distance measures and perform t-test on pairs of corpora represented
# as (smoothed) unigram language models

library(tm) # for constructing (sparse) document term matrices
library(slam) # for computing with sparse matrices
library(BSDA) # for t-test based on sample means and standard deviations

#read CQP tabulate
#choose file

#Tab-delimited input format
#docs <- read.table(file.choose(), header=T, fill=T, row.names=NULL, sep="\t")

#Semicolon-delimited input format
#docs <- read.table(file.choose(), header=T, fill=T, row.names=NULL, sep=";")

#Use document prepared for KLD
docs <- d4kld

#Set again starting year
firstp <- 1720 


#Set path for output files
path <- "C:\\Users\\Stefania\\Documents\\Stefania\\Dokumente\\Uni\\Konferenzen\\Coling2018\\released_script\\results\\"
dir.create(paste(path, sep=""))


#################### Preprocessing #########################


#Define columns with metadata (e.g. text-id is metadata) 
#CHANGE
#Last columns are selected based on amount of periods to be analyzed
docs.meta <- docs[,c(1:2,(ncol(docs)-period+2):ncol(docs))] #select from docs (your file) column 1 to 4
docs.meta
#Define columns with data (not metadata)
#first two columns are textid and year of publication
docs.dtm <- as.simple_triplet_matrix(docs[,3:(ncol(docs)-period)]) 




####### end of preprocessing #######

for(i in 1:period){
  
  p <- paste("p",firstp, sep = "")
  
  ######## Define groupindex, i.e. column with class that has to be compared 
  groupindex <- as.factor(docs[[p]])
  
  ######## Define classes (selectors) to be compared  ############
  #CHANGE
  # selectors for subcorpora
  #Comparison is always based on two corpora only
  sel1 <- "pre"
  sel2 <- "post"
  
  ######## Define ling. level of comparison (used for output file)
  #llevel <- "N" #nouns
  #llevel <- "words" #words
  llevel <- "pos3" #POS trigrams

  ######## Define Outputfile location
  #CHANGE to your directory
  #pos3
  file <- paste(path,firstp,sel1,sel2,llevel,".csv", sep = "")
  #lemma
  #file <- paste("C:\\Users\\Stefania\\Documents\\Stefania\\Dokumente\\Uni\\Saarbruecken\\SFB\\analyses\\dynamics-of-change\\lemma_new\\results\\sall",firstp,sel1,sel2,"_sp.csv", sep = "")
  
  ##Prepare for smoothing
  # sum up (absolute) frequencies for each class combination
  docs.group.freq <-rollup(docs.dtm,1L,groupindex,na.rm=TRUE,fun=sum)
  
  # sum up all frequencies  (for smoothing)
  docs.all.freq <-rollup(docs.dtm,1L,fun=sum)
  
  ##### Smoothing to allow comparison of different vocabulary size of (sub)corpora
  # calculate smoothed term probabilities
  # simple smoothing with 0.005 of background corpus
  # see Fankhauser et al. 2014, Exploring and Visualizing Variation in Language Resources
  # and Zhai and Lafferty 2004, A Study of Smoothing Methods for Language Models Applied to Information Retrieval
  # for evalution of smoothing methods with different lambdas
  lambda<-0.995
  
  docs.group.prob <-as.matrix(docs.group.freq/row_sums(docs.group.freq))
  docs.all.prob <-as.matrix(docs.all.freq/row_sums(docs.all.freq))
  
  #smooth probabilities to be comparable if corpora have different vocab size
  docs.group.smoothprob<-sweep(lambda*docs.group.prob,2,as.vector((1-lambda)*docs.all.prob),"+")
  
  ####### Definition of divergence measures ###########
  
  
  # Kullback-Leibler Divergence
  
  kld <- function(x,y) {
    if (y==0 && x > 0) {
      NaN
    }
    else if (x==0) {
      0
    }
    else {
      x*log2(x/y) 
      
    }
  }
  
  # Jensen-Shannon Divergence
  
  js <- function(x,y) {
    m <- (x+y)/2
    0.5*(kld(x,m)+kld(y,m))
  }
  
  # Jensen-Shannon Divergence ... individual terms
  
  js.left <- function(x,y) {
    m <- (x+y)/2
    kld(x,m)
  }
  
  js.right <- function(x,y) {
    m <- (x+y)/2
    kld(y,m)
  }
  
  # Chisquare
  
  chisquare <- function(o11,o12,o21,o22) {
    sum <- o11+o12+o21+o22
    e11 <- (o11+o12)*(o11+o21)/sum
    e12 <- (o11+o12)*(o12+o22)/sum
    e21 <- (o21+o22)*(o11+o21)/sum
    e22 <- (o21+o22)*(o12+o22)/sum
    (o11-e11)^2/e11+(o12-e12)^2/e12+(o21-e21)^2/e21+(o22-e22)^2/e22
  }
  # apply all divergence measures to a pair of corpora selected by sel1 and sel2
  compute_divergences <- function (sel1,sel2) {
    #smoothed probabilities
    prob1<-docs.group.smoothprob[sel1,,drop=FALSE]
    prob2<-docs.group.smoothprob[sel2,,drop=FALSE]
    #Apply KLD
    kld1 <- mapply(kld,prob1,prob2)
    kld2 <- mapply(kld,prob2,prob1)
    #Apply Jensen-Shannon
    js <- mapply(js,prob1,prob2)
    js.left <- mapply(js.left,prob1,prob2)
    js.right <- mapply(js.right,prob1,prob2)
    #Group frequencies
    freq1 <- as.matrix(docs.group.freq[sel1,])
    freq2 <- as.matrix(docs.group.freq[sel2,])
    #Sum frequencies
    sum1 <- sum(freq1)
    sum2 <- sum(freq2)
    #Rest frequencies 
    nfreq1 <- sum(freq1)-freq1
    nfreq2 <- sum(freq2)-freq2
    #Apply chisquare test
    chisquare <- mapply(chisquare,freq1,freq2,nfreq1,nfreq2)
    pchi <- 1.0-pchisq(chisquare,1)
    #Bind results
    res <- rbind(kld1,kld2,prob1,prob2,js,js.left,js.right,freq1,freq2,chisquare,pchi)
    #Define row and column names
    rownames(res) <- c("kld1","kld2","p1","p2","js","js1","js2","f1","f2","chi","pchi")
    colnames(res) <- colnames(prob1)
    #Build data frame
    data.frame(t(res))
  }
  
  
  #Compute divergences for the selected subcorpora
  divergences <- compute_divergences(sel1,sel2)
  #sorted
  sdivergences <- divergences[order(-divergences$kld2),]
  
  
  
  ###### Significance Testing ######
  
  # T-test
  
  # sparse variants of mean and standard deviation
  # x vector of values, nx number of 0 entries
  
  #Mean
  sparsemean <- function(x,nx) {
    n <- nx+length(x)
    if (n<1) {
      NA
    }
    else {
      sum(x)/n
    }
  }
  
  #Standard deviation
  sparsesd <- function(x,nx) {
    n <- nx+length(x)
    if (n<2) {
      NA
    }
    else {
      sum <- sum(x)
      sqrsum <- sum(x^2)
      sqrt((sqrsum-sum^2/n)/(n-1))
    }
  }
  
  # normalize frequencies by document length (unsmoothed probabilities)
  docs.dtm.norm <- docs.dtm/row_sums(docs.dtm)
  # means
  docs.group.prob.mean<-as.matrix(rollup(docs.dtm.norm,1L,groupindex,EXPAND="sparse",FUN=sparsemean))
  # standard deviations
  docs.group.prob.sd<-as.matrix(rollup(docs.dtm.norm,1L,groupindex,EXPAND="sparse",FUN=sparsesd))
  # number of documents per group
  docs.group.count<-table(groupindex)
  
  tsum.test.wrap <- function (m1,m2,s1,s2,n1,n2) {
    ttest<-tsum.test(m1, s.x=s1, n.x=n1, m2, s.y = s2,
                     n.y = n2, alternative = "two.sided", mu = 0, var.equal = FALSE,
                     conf.level = 0.95)
    ttest$p.value
  }
  
  compute_pvalues <- function(sel1,sel2) {
    means1 <- docs.group.prob.mean[sel1,,drop="FALSE"]
    means2 <- docs.group.prob.mean[sel2,,drop="FALSE"]
    sds1 <- docs.group.prob.sd[sel1,,drop="FALSE"]
    sds2 <- docs.group.prob.sd[sel2,,drop="FALSE"]
    ns1 <- as.vector(docs.group.count[sel1])
    ns2 <- as.vector(docs.group.count[sel2])
    res<-t(mapply(tsum.test.wrap,means1,means2,sds1,sds2,ns1,ns2))
    colnames(res)<-colnames(means1)
    rownames(res)<-c("pvalue")
    t(res)
  }
  
  pvalues <- compute_pvalues(sel1,sel2)
  
  # Combine all and sort/filter by various aspects
  all <- cbind(divergences,pvalues)
  all <- all[!is.nan(all$pvalue),]
  
  #Overall KLD
  kld1S <- sum(all$kld1)
  kld1S 
  
  kld2S <- sum(all$kld2)
  kld2S 
  
  #Difference
  klddiff <- kld1S - kld2S
  klddiff
  okld <- cbind(firstp,kld1S,kld2S,klddiff)

  kldfile <- paste(path,sel1,sel2,llevel,"kldsum.csv", sep = "")
  write.table(okld,kldfile, append = T, row.names=T, sep=";")
  
  #Significant in terms of relative frequency 
  sall <- all[order(-all$kld1),]
  head(sall)
  # filter everything with pvalue > 0.05
  sall <- sall[sall$pvalue<0.05,]
  #chisig <- sall[sall$pchi>0.05,]
  
  
  #WRITE table into directory
  #Write out only features showing significant difference 
  write.table(cbind(id=row.names(sall), as.data.frame(sall)), file, row.names=F, sep="\t")

  #Write out all features
  #write.table(all, file, sep=";")
  
  firstp <- firstp +gap #slide over the time line based on gap
}

firstp <- 1720

#multmerge function to merge data from different files by same column
multmerge = function(mypath){
  filenames=list.files(path=mypath, full.names=TRUE)
  datalist = lapply(filenames, function(x){read.csv(file=x,header=T)})
  Reduce(function(x,y) {merge(x,y, by.x="id", by.y="id", all=T)}, datalist)
}


#POST vs. PRE periods -> increasing change
direction <- "prepost"
dir.create(paste(path,"mergeme",direction, sep=""))

for(i in 1:period){
  
  #Define file names/directories
  file <- paste(path,firstp,direction,llevel,".csv", sep = "")
  outf <- paste(path,"mergeme",direction,"\\",firstp,direction,"_typF.csv", sep = "")

  d <- read.table(file, sep = "\t", header = T)
  head(d)
  #by kld1 or kld2
  d <- subset(d, select=c("id", "kld2"))
  write.csv(d, outf, row.names = F)
  firstp <- firstp +gap
}

#Define column names
firstp <- 1720

 vcolnames <- c(firstp)
 for(i in 1:50){
   firstp <- firstp + gap
   vcolnames <- append(vcolnames, firstp)
 }

data = multmerge(paste(path,"mergeme",direction, sep=""))  

colnames(data) <- c("", vcolnames)
head(data)

#Output data
write.table(data, paste(path,"mergeme",direction,"\\data",direction,".csv", sep=""), row.names = F, sep=";")


